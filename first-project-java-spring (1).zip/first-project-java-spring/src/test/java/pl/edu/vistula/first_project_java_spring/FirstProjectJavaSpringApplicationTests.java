package pl.edu.vistula.first_project_java_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstProjectJavaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
